package com.example.microservice.demoMicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
