package com.example.microservice_restAPI.microservice_restAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
