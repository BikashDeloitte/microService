package com.example.microservice_restAPI.microservice_restAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceRestApiApplication.class, args);
	}

}
